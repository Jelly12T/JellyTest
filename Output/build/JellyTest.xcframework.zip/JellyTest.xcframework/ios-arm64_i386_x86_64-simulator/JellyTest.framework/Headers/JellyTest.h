//
//  JellyTest.h
//  JellyTest
//
//  Created by Thạch Lê on 10/10/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for JellyTest.
FOUNDATION_EXPORT double JellyTestVersionNumber;

//! Project version string for JellyTest
FOUNDATION_EXPORT const unsigned char JellyTestVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JellyTest/PublicHeader.h>


